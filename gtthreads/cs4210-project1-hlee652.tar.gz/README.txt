1. Type 'make' to compile the GTThreads library 
2. ./bin/matrix 1 to run the matrix program with credit scheduler
